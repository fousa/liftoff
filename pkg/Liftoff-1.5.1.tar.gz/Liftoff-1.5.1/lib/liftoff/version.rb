module Liftoff
  VERSION = '1.5.1'
end
