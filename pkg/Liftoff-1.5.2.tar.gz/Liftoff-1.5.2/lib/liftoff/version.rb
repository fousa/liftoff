module Liftoff
  VERSION = '1.5.2'
end
