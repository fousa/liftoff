module Liftoff
  VERSION = '1.5.3'
end
